#!/bin/sh
trap cleanup HUP INT TERM

CONFIG_DIR="/opt/etc/keensnap"
RED='\033[1;31m'
GREEN='\033[1;32m'
CYAN='\033[0;36m'
NC='\033[0m'
USERNAME="KirillShchetinnikov"
REPO="keensnap"
SCRIPT="keensnap.sh"
KEENSNAP_DIR="/opt/root/KeenSnap"
. "$KEENSNAP_DIR/keensnap-config.sh" || exit 1
SNAPD="keensnap-init"
CRON_FILE="/opt/etc/crontab"
CRON_MARKER="# KeenSnap"
CRON_PATH="/opt/sbin:/opt/bin:/opt/usr/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
LOG_FILE="/opt/var/log/keensnap.log"
SCRIPT_VERSION="1.5.10"
KEENSNAP_USERAGENT="KeenSnap/$SCRIPT_VERSION"
RCI_URL="http://127.0.0.1:79/rci"

print_help() {
  cat <<EOF
KeenSnap ${SCRIPT_VERSION}

Использование:
  keensnap <команда>

Команды:
  help, -h, --help      Показать эту справку
  version              Показать версию
  status               Показать краткий статус устройства и конфигурации
  config               Вывести итоговые значения конфигурации
  logs                 Вывести $LOG_FILE
  apply                Применить конфигурацию и обновить cron
  backup               Запустить бэкап вручную
  update               Обновить пакет через opkg

Конфигурация:
  Пользовательские переопределения (в порядке имён файлов):
    $CONFIG_OVERRIDE_DIR/*.conf

  Значения по умолчанию находятся в:
    $DEFAULT_CONFIG_FILE

  Расписание задаётся в cron-синтаксисе из 5 полей:
    CRON_SCHEDULE="0 3 * * *"

  Чтобы отключить автоматический запуск:
    CRON_SCHEDULE=""

Примеры:
  keensnap status
  keensnap apply
  keensnap backup
  keensnap logs
EOF
}

print_message() {
  local message="$1"
  local color="${2:-$NC}"
  printf "${color}%s${NC}\n" "$message"
}

rci_curl() {
  local rci_token
  rci_token=$(get_config_value "RCI_TOKEN")
  if [ -n "$rci_token" ]; then
    curl -A "$KEENSNAP_USERAGENT" -H "X-Ndma-Tkn: $rci_token" "$@"
  else
    curl -A "$KEENSNAP_USERAGENT" "$@"
  fi
}

rci_request() {
  local endpoint="$1"
  rci_curl -s "$RCI_URL/$endpoint"
}

get_device() {
  rci_request "show/version" | grep -o '"device": "[^"]*"' | cut -d'"' -f4 2>/dev/null
}

get_fw_version() {
  rci_request "show/version" | grep -o '"release": "[^"]*"' | cut -d'"' -f4 2>/dev/null
}

get_hw_id() {
  rci_request "show/version" | grep -o '"hw_id": "[^"]*"' | cut -d'"' -f4 2>/dev/null
}

get_system_description() {
  rci_request "system" | grep -o '"description"[[:space:]]*:[[:space:]]*"[^"]*"' | head -n 1 | cut -d'"' -f4 2>/dev/null
}

get_system_name() {
  rci_request "system" | grep -o '"hostname"[[:space:]]*:[[:space:]]*"[^"]*"' | head -n 1 | cut -d'"' -f4 2>/dev/null
}

normalize_path() {
  local value="$1"
  while [ "$value" != "/" ] && [ "${value%/}" != "$value" ]; do
    value="${value%/}"
  done
  echo "$value"
}

get_config_bool() {
  local key="$1"
  local default="$2"
  local value
  value=$(get_config_value "$key")
  case "$value" in
  true | false) echo "$value" ;;
  *) echo "$default" ;;
  esac
}

format_upload_methods() {
  local methods="$1"
  local bucket_name="$2"
  local method
  local formatted=""

  methods=$(echo "$methods" | tr ',' ' ' | tr ' ' '\n' | sed '/^$/d' | awk '!seen[$0]++')
  for method in $methods; do
    if [ "$method" = "S3" ] && [ -n "$bucket_name" ]; then
      method="S3 (s3://$bucket_name)"
    fi
    formatted="${formatted}${formatted:+, }$method"
  done
  echo "$formatted"
}

get_backup_content() {
  local selected=""
  local entry
  local key
  local label
  local backup_system
  backup_system=$(get_config_bool "BACKUP_SYSTEM" "false")

  for entry in \
    "BACKUP_SYSTEM:System" \
    "BACKUP_STARTUP_CONFIG:Startup-Config" \
    "BACKUP_FIRMWARE:Firmware" \
    "BACKUP_ENTWARE:Entware" \
    "BACKUP_WG_PRIVATE_KEY:WireGuard-Private-Key"; do
    key=${entry%%:*}
    label=${entry#*:}
    case "$key" in
      BACKUP_STARTUP_CONFIG|BACKUP_FIRMWARE|BACKUP_WG_PRIVATE_KEY)
        [ "$backup_system" = "true" ] && continue
        ;;
    esac
    [ "$(get_config_bool "$key" "false")" = "true" ] && selected="${selected}${selected:+, }$label"
  done

  [ -n "$selected" ] && echo "$selected"
}

setup_config() {
  load_config
}

check_config() {
  setup_config || exit 1
}

show_status() {
  check_config

  local device
  local hw_id
  local fw_version
  local system_name
  local system_description
  local cron_schedule
  local selected_drive
  local upload_methods
  local s3_bucket_name
  local backup_content

  device=$(get_device)
  hw_id=$(get_hw_id)
  fw_version=$(get_fw_version)
  system_name=$(get_system_name)
  system_description=$(get_system_description)
  cron_schedule=$(get_config_value "CRON_SCHEDULE")
  selected_drive=$(normalize_path "$(get_config_value "SELECTED_DRIVE")")
  upload_methods=$(get_config_value "UPLOAD_METHOD")
  s3_bucket_name=$(get_config_value "S3_BUCKET_NAME")
  upload_methods=$(format_upload_methods "$upload_methods" "$s3_bucket_name")
  backup_content=$(get_backup_content)

  [ -z "$device" ] && device="unknown"
  [ -z "$hw_id" ] && hw_id="unknown"
  [ -z "$fw_version" ] && fw_version="unknown"
  [ -z "$system_name" ] && system_name="не задано"
  [ -z "$system_description" ] && system_description="не задано"
  [ -z "$cron_schedule" ] && cron_schedule="disabled"
  [ -z "$selected_drive" ] && selected_drive="not set"
  [ -z "$upload_methods" ] && upload_methods="not set"
  [ -z "$backup_content" ] && backup_content="not set"

  printf "${CYAN}Модель:${NC} %s (%s)\n" "$device" "$hw_id"
  printf "${CYAN}KeeneticOS:${NC} %s\n" "$fw_version"
  printf "${CYAN}Имя системы:${NC} %s\n" "$system_name"
  printf "${CYAN}Описание системы:${NC} %s\n" "$system_description"
  printf "${CYAN}Версия KeenSnap:${NC} %s by %s\n" "$SCRIPT_VERSION" "$USERNAME"
  printf "${CYAN}Cron:${NC} %s\n" "$cron_schedule"
  printf "${CYAN}Накопитель:${NC} %s\n" "$selected_drive"
  printf "${CYAN}Отправка:${NC} %s\n" "$upload_methods"
  printf "${CYAN}Состав:${NC} %s\n" "$backup_content"
}

show_config() {
  check_config
  local line
  local key

  printf '%s\n' "# Итоговая конфигурация: $DEFAULT_CONFIG_FILE + $CONFIG_OVERRIDE_DIR/*.conf"

  while IFS= read -r line || [ -n "$line" ]; do
    case "$line" in
      [A-Za-z_]*=*)
        key=${line%%=*}
        printf '%s=' "$key"
        get_config_value "$key" | sed "s/'/'\\\\''/g; 1s/^/'/; \$s/\$/'/"
        ;;
    esac
  done <"$DEFAULT_CONFIG_FILE"
}

show_logs() {
  check_config
  local log_file
  log_file=$(get_config_value "LOG_FILE")
  if [ -f "$log_file" ]; then
    cat "$log_file"
  else
    echo "Лог-файл пока не создан"
  fi
}

validate_cron_schedule() {
  local cron_schedule="$1"
  set -f
  set -- $cron_schedule
  set +f
  [ "$#" -eq 5 ]
}

restart_cron() {
  if [ -x "/opt/etc/init.d/S10cron" ]; then
    /opt/etc/init.d/S10cron restart >/dev/null 2>&1 && return 0
    /opt/etc/init.d/S10cron start >/dev/null 2>&1 && return 0
  fi

  if command -v crond >/dev/null 2>&1; then
    killall crond >/dev/null 2>&1
    crond >/dev/null 2>&1 && return 0
  fi

  return 1
}

fix_cron_file_permissions() {
  chown root:root "$CRON_FILE" 2>/dev/null || chown 0:0 "$CRON_FILE" 2>/dev/null || return 1
  chmod 600 "$CRON_FILE" 2>/dev/null || return 1
}

apply_cron_schedule() {
  check_config

  local cron_schedule
  cron_schedule=$(get_config_value "CRON_SCHEDULE")

  if [ -n "$cron_schedule" ] && ! validate_cron_schedule "$cron_schedule"; then
    print_message "CRON_SCHEDULE должен содержать 5 cron-полей" "$RED"
    return 1
  fi

  mkdir -p "$(dirname "$CRON_FILE")"
  touch "$CRON_FILE"
  sed -i "\|$CRON_MARKER|d" "$CRON_FILE"

  if [ -n "$cron_schedule" ]; then
    printf '%s root PATH=%s %s start cron %s\n' "$cron_schedule" "$CRON_PATH" "$KEENSNAP_DIR/$SNAPD" "$CRON_MARKER" >>"$CRON_FILE"
  fi

  if ! fix_cron_file_permissions; then
    print_message "Не удалось установить владельца root:root для $CRON_FILE. Запустите: sudo keensnap apply" "$RED"
    return 1
  fi

  if restart_cron; then
    print_message "Конфиг применён" "$GREEN"
  else
    print_message "Cron-запись обновлена, но cron не перезапущен" "$RED"
    return 1
  fi
}

manual_backup() {
  check_config
  "$KEENSNAP_DIR/$SNAPD" start manual
}

packages_checker() {
  local missing=""
  for pkg in "$@"; do
    if ! opkg list-installed | grep -q "^$pkg"; then
      missing="$missing $pkg"
    fi
  done
  if [ -n "$missing" ]; then
    opkg update && opkg install $missing
    echo ""
  fi
}

script_update() {
  local mode="${1:-manual}"
  packages_checker curl tar ca-certificates wget-ssl jq cron
  if opkg update && opkg install "$REPO"; then
    if [ "$mode" = "silent" ]; then
      logger -p notice -t KeenSnap "Пакет обновлён в silent-режиме"
    else
      print_message "Пакет обновлён" "$GREEN"
    fi
    exit 0
  fi

  if [ "$mode" = "silent" ]; then
    logger -p err -t KeenSnap "Ошибка при обновлении пакета"
  else
    print_message "Не удалось обновить пакет. Выполните обновление вручную." "$RED"
  fi
  exit 1
}

cleanup() {
  pkill -P $$ 2>/dev/null
}

case "${1:-help}" in
  help|-h|--help)
    print_help
    ;;
  version|--version)
    echo "$SCRIPT_VERSION"
    ;;
  status)
    show_status
    ;;
  config|show-config)
    show_config
    ;;
  logs|show-logs)
    show_logs
    ;;
  apply|apply-config)
    apply_cron_schedule
    ;;
  backup|run|start)
    manual_backup
    ;;
  update)
    script_update "manual"
    ;;
  script_update)
    script_update "$2"
    ;;
  *)
    print_message "Неизвестная команда: $1" "$RED" >&2
    echo "" >&2
    print_help >&2
    exit 1
    ;;
esac
